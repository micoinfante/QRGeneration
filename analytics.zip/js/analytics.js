
var db = firebase.firestore();
var hQIds = "qORS5giJWx101ituzXveVZPqQENAh1hEriCRyeTP";
var data = [];
var obj = new Object();
var weekParser = null

window.onload = async function () {
  await db.collection("PointHistory").where("mainID", "==", hQIds).where("redeem", "==", "redeemed").get().then(function (querySnapshot) {
    querySnapshot.forEach(function (doc) {
      var coupoIDs = doc.data().couponID
      var time = doc.data().timeStamp
      var couponName = doc.data().couponItem
      obj = {
        label: couponName,
        time: time.toDate(),
        couponID: coupoIDs
      }

      data.push(obj)
    })
  }).catch(function (err) {
    console.log(err);
  })
  historyParser = new HistoryParser(data);
};

function resetup(type) {
  historyParser.resetup(type)
}