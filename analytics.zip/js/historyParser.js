class HistoryParser {
  /*
  @param arr - json array of Points history
  */
  constructor(arr) {
    this.dataset = {};
    var monthLabels = [];

    var monthHistory = {};
    var dayHistory = {};
    var hourHistory = {};

    function generateStringHourConstants() {
      var _time = {};

      // AM
      _time[`12:00 AM to 1:00 AM`] = 0
      for (var i = 1; i < 11; i++) {
        _time[`${i}:00 AM to ${i+1}:00 AM`] = 0
      }
      _time[`11:00 AM to 12:00 PM`] = 0
      // END AM
      _time[`12:00 PM to 1:00 PM`] = 0
      for (var i = 1; i < 11; i++) {
        _time[`${i}:00 PM to ${i+1}:00 PM`] = 0
      }
      _time[`11:00 PM to 12:00 AM`] = 0

      return _time;
    }

    function generateHourConstants() {
      var time = {}
      for (var i = 1; i < 24; i++) {
        time[i] = 0;
      }
      return time
    }
    /*
       ramen : {
         history: {
           weekday: {
             Sunday: 0,
             ...
           },
           day: {
             
           }
         },
         timestamps: []
       }
     */

    function sortByTimeConstraint(day, month, hour, data) {
      // parse time up to day today
      let currentMonthVal = data.history.months[month];
      let currentDayVal = data.history.weekdays[day];
      let hourIndex = parseHours(hour);
      let currentHourVal = data.history.hours[hourIndex];
      data.history.weekdays[day] = currentDayVal + 1;
      data.history.months[month] = currentMonthVal + 1;
      data.history.hours[hourIndex] = currentHourVal + 1;
      return data;
    }

    console.log(arr);
    arr.forEach(item => {
      // if key exists in object, add date and increment count
      let date = new Date(item.time);

      let itemDay = date.toLocaleString('default', {
        weekday: 'long'
      });
      let itemMonth = date.toLocaleString('default', {
        month: 'long'
      });
      let itemHour = new Date(item.time).getHours()

      if (this.dataset.hasOwnProperty(item.label)) {
        this.dataset[item.label].timestamps.push(item.time);
        var data = this.dataset[item['label']];
        var sortedData = sortByTimeConstraint(itemDay, itemMonth, itemHour, data)
        this.dataset[item.label] = sortedData;
      } else {
        // if couponItem doesnt exist, add it as a new key
        var DAYS = {
          Sunday: 0,
          Monday: 0,
          Tuesday: 0,
          Wednesday: 0,
          Thursday: 0,
          Friday: 0,
          Saturday: 0
        };
        var HOURS = generateHourConstants()
        var MONTHS = {
          January: 0,
          February: 0,
          March: 0,
          April: 0,
          May: 0,
          June: 0,
          July: 0,
          August: 0,
          September: 0,
          October: 0,
          November: 0,
          December: 0
        };
        this.dataset[item.label] = {
          couponID: item.couponID,
          timestamps: [item.time],
          history: {
            weekdays: DAYS,
            months: MONTHS,
            hours: HOURS
          }
        };

        this.dataset[item.label].history.weekdays[itemDay] = 1;
        this.dataset[item.label].history.months[itemMonth] = 1;
        var index = parseHours(itemHour)
        this.dataset[item.label].history.hours[index] = 1;
        // parse per hour
        // dataset[item.label].history[itemHour] = 1;
      }

    });
    // console.log(dataset)
    this.setup(this.dataset, 'day')
  }

  setup(dataset, type) {

    var hourCanvas = document.getElementById('hourChart').getContext('2d');
    var dayCanvas = document.getElementById('dayChart').getContext('2d');
    var monthCanvas = document.getElementById('monthChart').getContext('2d');

    var titleLabels = [];
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var hours = generateStringHourConstants()
    var monthData = {
      labels: months,
      datasets: []
    };
    var hourData = {
      labels: hours,
      datasets: []
    };
    var dayData = {
      labels: days,
      datasets: []
    };

    function generateStringHourConstants() {
      var _time = [];

      // AM
      _time.push(`12:00 AM to 1:00 AM`)
      for (var i = 1; i < 11; i++) {
        _time.push(`${i}:00 AM to ${i+1}:00 AM`)
      }
      _time.push(`11:00 AM to 12:00 PM`)
      // END AM
      _time.push(`12:00 PM to 1:00 PM`)
      for (var i = 1; i < 11; i++) {
        _time.push(`${i}:00 PM to ${i+1}:00 PM`)
      }
      _time.push('11:00 PM to 12:00 AM')

      return _time;
    }

    function random_rgba() {
      var o = Math.round,
        r = Math.random,
        s = 255;
      return 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + r().toFixed(0.2) + ')';
    }

    function dynamicColors() {
      var r = Math.floor(Math.random() * 255);
      var g = Math.floor(Math.random() * 255);
      var b = Math.floor(Math.random() * 255);
      return "rgba(" + r + "," + g + "," + b + ", 0.5)";
    }

    var rawData = dataset

    for (var key in rawData) {

      var currData = rawData;
      var historyValue = [];
      var _monthData, _dayData, _hourData = []

      _monthData = Object.values(dataset[key].history.months)
      monthData.labels = months

      _hourData = Object.values(dataset[key].history.hours)
      hourData.labels = hours

      _dayData = Object.values(dataset[key].history.weekdays)
      dayData.labels = days


      var randomColor = dynamicColors()
      var randomBG = random_rgba;
      var monthlyData = [];

      var monthDataset = {
        backgroundColor: randomColor,
        strokeColor: randomColor,
        pointColor: randomColor,
        pointStrokeColor: randomColor,
        data: _monthData,
        label: key,
        barThickness: 20,
        hoverBorderWidth: 4,
        pointRadius: 4,
        pointHoverRadius: 10
      }
      var hourDataset = {
        backgroundColor: randomColor,
        strokeColor: randomColor,
        pointColor: randomColor,
        pointStrokeColor: randomColor,
        data: _hourData,
        label: key,
        barThickness: 20,
        hoverBorderWidth: 4,
        pointRadius: 4,
        pointHoverRadius: 10
      }
      var dayDataset = {
        backgroundColor: randomColor,
        strokeColor: randomColor,
        pointColor: randomColor,
        pointStrokeColor: randomColor,
        data: _dayData,
        label: key,
        barThickness: 20,
        hoverBorderWidth: 4,
        pointRadius: 4,
        pointHoverRadius: 10
      }
      monthData.datasets.push(monthDataset)
      dayData.datasets.push(dayDataset)
      hourData.datasets.push(hourDataset)
    }

    var xChart = new Chart(hourCanvas, {
      type: 'line',
      data: hourData,
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });

    var yChart = new Chart(dayCanvas, {
      type: 'line',
      data: dayData,
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });

    var zChart = new Chart(monthCanvas, {
      type: 'line',
      data: monthData,
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });

  }

  resetup(type) {
    this.setup(this.dataset, type)
  }



} // class