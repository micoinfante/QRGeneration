    function parseHours(hour) {

      if (hour >= 0 && hour <= 1) {
        return 0
      } else if (hour >= 1 && hour <= 2) {
        return 1
      } else if (hour >= 2 && hour <= 3) {
        return 2
      } else if (hour >= 3 && hour <= 4) {
        return 3
      } else if (hour >= 4 && hour <= 5) {
        return 4
      } else if (hour >= 5 && hour <= 6) {
        return 5
      } else if (hour >= 6 && hour <= 7) {
        return 6
      } else if (hour >= 7 && hour <= 8) {
        return 7
      } else if (hour >= 8 && hour <= 9) {
        return 8
      } else if (hour >= 9 && hour <= 10) {
        return 9
      } else if (hour >= 10 && hour <= 11) {
        return 10
      } else if (hour >= 11 && hour <= 12) {
        return 11
      } else if (hour >= 13 && hour <= 14) {
        return 12
      } else if (hour >= 14 && hour <= 15) {
        return 13
      } else if (hour >= 15 && hour <= 16) {
        return 15
      } else if (hour >= 16 && hour <= 17) {
        return 16
      } else if (hour >= 17 && hour <= 18) {
        return 17
      } else if (hour >= 18 && hour <= 19) {
        return 18
      } else if (hour >= 19 && hour <= 20) {
        return 19
      } else if (hour >= 20 && hour <= 21) {
        return 20
      } else if (hour >= 20 && hour <= 21) {
        return 21
      } else if (hour >= 21 && hour <= 22) {
        return 22
      } else if (hour >= 22 && hour <= 23) {
        return 23
      } else if (hour >= 23 && hour <= 24) {
        return 24
      }
    }

    function parseHours1(hour) {

      if (hour >= 0 && hour <= 1) {

        return 0
      } else if (hour >= 1 && hour <= 2) {

        return 1
      } else if (hour >= 2 && hour <= 3) {

        return 2
      } else if (hour >= 3 && hour <= 4) {

        return 3
      } else if (hour >= 4 && hour <= 5) {

        return 4
      } else if (hour >= 5 && hour <= 6) {

        return 5
      } else if (hour >= 6 && hour <= 7) {

        return 6
      } else if (hour >= 7 && hour <= 8) {

        return 7
      } else if (hour >= 8 && hour <= 9) {

        return 8
      } else if (hour >= 9 && hour <= 10) {

        return 9
      } else if (hour >= 10 && hour <= 11) {

        return 10
      } else if (hour >= 11 && hour <= 12) {

        return 11
      } else if (hour >= 13 && hour <= 14) {

        return 12
      } else if (hour >= 14 && hour <= 15) {

        return 13
      } else if (hour >= 15 && hour <= 16) {

        return 15
      } else if (hour >= 16 && hour <= 17) {

        return 16
      } else if (hour >= 17 && hour <= 18) {

        return 17
      } else if (hour >= 18 && hour <= 19) {

        return 18
      } else if (hour >= 19 && hour <= 20) {

        return 19
      } else if (hour >= 20 && hour <= 21) {

        return 20
      } else if (hour >= 20 && hour <= 21) {

        return 21
      } else if (hour >= 21 && hour <= 22) {

        return 22
      } else if (hour > 22 && hour <= 23) {

        return 23
      } else if (hour > 23 && hour <= 24) {

        return 24
      }

    }